nohup java -jar Game.jar -n 'Game' -i 0 -p 10050 > Game_0.out &
sleep 3

