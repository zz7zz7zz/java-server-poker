nohup java -jar Login.jar -n 'Login' -i 0 -p 10020 > Login_0.out &
sleep 3
