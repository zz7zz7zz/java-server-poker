#!/bin/bash

#---------------------------启动Start---------------------------

#---------------------------启动监视器---------------------------
cd Monitor
chmod 777 start.sh
./start.sh
cd ../

#---------------------------启动Dispatcher---------------------------
cd Dispatcher
chmod 777 start.sh
./start.sh
cd ../


#---------------------------启动Access---------------------------
cd Access
chmod 777 start.sh
./start.sh
cd ../

#---------------------------启动User---------------------------
cd User
chmod 777 start.sh
./start.sh
cd ../

#---------------------------启动Login---------------------------
cd Login
chmod 777 start.sh
./start.sh
cd ../

#---------------------------启动Allocator---------------------------
cd Allocator
chmod 777 start.sh
./start.sh
cd ../

#---------------------------启动Allocator---------------------------
cd Game
chmod 777 start.sh
./start.sh
cd ../

#---------------------------启动End---------------------------


