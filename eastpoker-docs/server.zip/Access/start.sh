nohup java -jar Access.jar -n 'Access' -i 0 -p 10010 > Access_0.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 1 -p 10011 > Access_1.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 2 -p 10012 > Access_2.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 3 -p 10013 > Access_3.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 4 -p 10014 > Access_4.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 5 -p 10015 > Access_5.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 6 -p 10016 > Access_6.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 7 -p 10017 > Access_7.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 8 -p 10018 > Access_8.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 9 -p 10019 > Access_9.out &
sleep 3
