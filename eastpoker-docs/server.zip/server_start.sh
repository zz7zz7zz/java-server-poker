#!/bin/bash
#---------------------------(Start)---------------------------



#---------------------------1.启动监视器---------------------------
cd Monitor
chmod 777 start.sh
./start.sh
cd ../

#---------------------------2.启动Dispatcher---------------------------
cd Dispatcher
chmod 777 start.sh
./start.sh
cd ../

#---------------------------3.启动User---------------------------
cd User
chmod 777 start.sh
./start.sh
cd ../

#---------------------------4.启动Login---------------------------
cd Login
chmod 777 start.sh
./start.sh
cd ../

#---------------------------5.启动Allocator---------------------------
cd Allocator
chmod 777 start.sh
./start.sh
cd ../

#---------------------------6.启动Allocator---------------------------
cd Game
chmod 777 start.sh
./start.sh
cd ../

#---------------------------7.启动Access---------------------------
cd Access
chmod 777 start.sh
./start.sh
cd ../



#---------------------------(End)---------------------------


