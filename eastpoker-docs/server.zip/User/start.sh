nohup java -jar User.jar -n 'User' -i 0 -p 10030 > User_0.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 1 -p 10031 > User_1.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 2 -p 10032 > User_2.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 3 -p 10033 > User_3.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 4 -p 10034 > User_4.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 5 -p 10035 > User_5.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 6 -p 10036 > User_6.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 7 -p 10037 > User_7.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 8 -p 10038 > User_8.out &
sleep 3

nohup java -jar User.jar -n 'User' -i 9 -p 10039 > User_9.out &
sleep 3
