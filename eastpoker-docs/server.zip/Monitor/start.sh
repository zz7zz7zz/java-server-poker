nohup java -jar Monitor.jar -n 'Monitor' -i 0 -p 9999 > Monitor_0.out &
sleep 3
