nohup java -jar Allocator.jar -n 'Allocator' -i 500 -p 10040 > Allocator_0.out &
sleep 3

