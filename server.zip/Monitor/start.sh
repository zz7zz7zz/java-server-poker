nohup java -jar Monitor.jar &
