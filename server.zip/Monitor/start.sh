nohup java -jar Monitor.jar -n 'Monitor' -i 0 -p 9999 > monitor_0.out &
sleep 3
