nohup java -jar Monitor.jar -n 'Monitor' -i 0 -p 9999 &
