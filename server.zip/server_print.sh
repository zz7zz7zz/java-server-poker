ps -ef | grep -v grep | grep long | grep java --color=auto
