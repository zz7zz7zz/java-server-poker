nohup java -jar Allocator.jar -n 'Allocator' -i 500 -p 10030 > Allocator_0.out &
sleep 3

