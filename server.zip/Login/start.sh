nohup java -jar Login.jar -n 'Login' -i 0 -p 10020 > access_0.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 1 -p 10021 > login_1.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 2 -p 10022 > login_2.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 3 -p 10023 > login_3.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 4 -p 10024 > login_4.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 5 -p 10025 > login_5.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 6 -p 10026 > login_6.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 7 -p 10027 > login_7.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 8 -p 10028 > login_8.out &
sleep 3

nohup java -jar Login.jar -n 'Login' -i 9 -p 10029 > login_9.out &
sleep 3
