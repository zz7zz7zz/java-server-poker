nohup java -jar Access.jar -n 'Access' -i 0 -p 10010 > access_0.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 1 -p 10011 > access_1.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 2 -p 10012 > access_2.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 3 -p 10013 > access_3.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 4 -p 10014 > access_4.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 5 -p 10015 > access_5.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 6 -p 10016 > access_6.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 7 -p 10017 > access_7.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 8 -p 10018 > access_8.out &
sleep 3

nohup java -jar Access.jar -n 'Access' -i 9 -p 10019 > access_9.out &
sleep 3
